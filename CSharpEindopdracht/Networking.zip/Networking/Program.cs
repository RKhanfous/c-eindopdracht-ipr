﻿using Networking.Utils;
using SharedSkribbl;
using System;
using System.Linq;

namespace Networking
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //Line line = new Line
            //{
            //    Id = 0,
            //    BeginX = 1,
            //    BeginY = 2,
            //    EndX = 3,
            //    EndY = 4,
            //    StrokeWidth = 5,
            //    Color = 6
            //};

            //byte[] message = DataParser.GetLineMessage(line);
            //Console.WriteLine(BitConverter.ToString(message));
            //Line deserializedLine = DataParser.getLineFromPayload(message.Skip(3).ToArray());

            //Console.WriteLine(deserializedLine.BeginX);
        }
    }
}
